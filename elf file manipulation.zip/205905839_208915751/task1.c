#include <elf.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

typedef struct{
    char debugMod;
    char fileName[128];
    int size;
    unsigned char mem_buf[10000];
    size_t mem_count; 

} state;

int fd=-1;
void *map_star;
struct stat fileDesc_stat;
struct fun_desc{
    char *name;
    void (*fun)(state* s);
};
int debug_mode=0; //0 is off 1 is on

void ToggleDebugMode(state* s){
    if(debug_mode-'1'==0)
    {
        debug_mode='0';
        printf("Debug flag is now off.\n");
    }
    else{
        debug_mode='1';
        printf("Debug flag is now on.\n");
    }
}
void ExamineElfFile(state* s)
{
    Elf32_Ehdr *head;
    int section;
    int entry;
    char buf[1024];
    printf("Please enter Elf file name: \n");
    fgets(buf,1024,stdin);
    buf[strlen(buf)-1]='\0';

    if(fd!=-1&& fd!=0)
        close(fd);
    if((fd =open(buf,O_RDONLY))<0){
        perror("failed to open file\n");
        fd=-1;
        free(s);
        exit(-1);
    }
    if(fstat(fd,&fileDesc_stat)!=0){
        perror("stat failed \n");
        close(fd);
        fd=-1;
        exit(1);
    }
    if((map_star=mmap(0,fileDesc_stat.st_size,PROT_READ,MAP_PRIVATE,fd,0))==MAP_FAILED){
        perror("mmap failed \n");
        munmap(map_star,fileDesc_stat.st_size);
        close(fd);
        fd=-1;
        free(s);
        exit(1);
    }

    head=(Elf32_Ehdr*) map_star;
    //prinbting the magic numbers(the firts three chars in the ident).
    printf("The magic numbers are: %c %c %c\n",head->e_ident[1],head->e_ident[2],head->e_ident[3]);
    if((head->e_ident[1]!='E' )&&(head->e_ident[2]!='L')&&(head->e_ident[3]!='F' )){
        fprintf(stderr,"The current file is not an elf.\n");
        munmap(map_star,fileDesc_stat.st_size);
        close(fd);
        fd=-1;
        return;
    }
    if(head->e_ident[4]==0)
    printf("The data encoding is invalid\n");
    else if(head->e_ident[4]==1){
        printf("The data encoding is 2's complement with little endian.\n");
    }
    else if(head->e_ident[4]==2){
        printf("The data encoding is 2's complement with big endian.\n");
    }
    printf("File entry point: %X\n",head->e_entry);
    printf("The file offset in which the section header table resides: %d\n",section= head->e_shoff);
    printf("The number of section header entries: %d\n",head->e_shnum);
    printf("The size of each section header entry: %d\n",head->e_shentsize);
    printf("The file offset in which the program header table resides: %d\n",head->e_phoff);
    printf("The number of program header entries: %d\n", entry=head->e_phnum);
    printf("The size of each program header entry: %d\n",head->e_phentsize);

}
void PrintSectionNames(state* s)
{
    Elf32_Ehdr * head;
    if(fstat(fd,&fileDesc_stat)!=0){
        perror("Failed to stat.\n");
        close(fd);
        fd=-1;
        exit(1);
    }
    //pointer to the elf header.
    head=(Elf32_Ehdr*)map_star;
    //pointer to the table of sections.
    Elf32_Shdr * sectionHeader = (Elf32_Shdr*)(map_star + head->e_shoff);
    //number of sections in the table.
    int sectionHeaderNum= head->e_shnum;
    //entry of the string table in the sections table.
    Elf32_Shdr * sectionsEntry=&sectionHeader[head->e_shstrndx];
    //pointer to the string table.
    char* tablePointer= map_star + sectionsEntry->sh_offset;

    if(s->debugMod-'1'==0)
    {
        fprintf(stderr,"DEBUG: shstrndx = %d\n", head->e_shstrndx);
    }
    printf("\tName\t\t\tAddress\t\tOffset\t\tSize\t\tType\n");
    int j;
    for(j=0;j<sectionHeaderNum;j++){
        printf("[%2d]",j);
        if(strlen(tablePointer+sectionHeader[j].sh_name)==0){
            printf("%s\t\t\t\t",tablePointer+sectionHeader[j].sh_name);
        }
        else if(strlen(tablePointer+sectionHeader[j].sh_name)>11){
            printf("%s\t\t",tablePointer+sectionHeader[j].sh_name);
        }
        else{
            printf("%s\t\t\t",tablePointer+sectionHeader[j].sh_name);
        }
        printf("%#09X\t",sectionHeader[j].sh_addr);
        printf("%#X\t",sectionHeader[j].sh_offset);
        printf("%#X\t",sectionHeader[j].sh_size);
        printf("%#X\t\n",sectionHeader[j].sh_type);
        if(s->debugMod-'1'==0)
            fprintf(stderr,"DEBUG: section name offset is: %#X\n\n",sectionHeader[j].sh_name);
    }
}
void PrintSymbols(state* s)
{
    printf("Not implemented yet.\n");
}
void RelocationTables(state* s)
{
    printf("Not implemented yet.\n");   
}
void Quit(state* s)
{
    if(s->debugMod=='1')
        printf("Quitting nurmally...\n");
    munmap(map_star,fileDesc_stat.st_size);
    close(fd);
    free(s);
    exit(0);
}

int main(){
    state* s=malloc(sizeof(state));
    struct fun_desc menu[]={{"Toggle Debug Mode",ToggleDebugMode},{"Examine ELF File",ExamineElfFile},
    {"Print Section Names",PrintSectionNames},{"Print Symbols",PrintSymbols},{"Relocation Tables",RelocationTables},
    {"Quit",Quit},{NULL,NULL}};
    while (1)
	    {
            int i=0;
            while (menu[i].name!=NULL)
            {
                printf("%d- %s\n",i,menu[i].name);
                i++;
            }
            char in[1024];
            int option;
            option=atoi(fgets(in,1024,stdin));
            if ((option>i)||(option<0))
            {
                printf("option not valid\n");
            }
            else
            {
                menu[option].fun(s);
            }

	    }
        free(s);
       
}