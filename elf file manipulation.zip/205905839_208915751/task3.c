#include <elf.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

typedef struct{
    char debugMod;
    char fileName[128];
    int size;
    unsigned char mem_buf[10000];
    size_t mem_count; 

} state;

int fd=-1;
void *map_star;
struct stat fileDesc_stat;
struct fun_desc{
    char *name;
    void (*fun)(state* s);
};

void ToggleDebugMode(state* s){
    if(s->debugMod-'1'==0)
    {
        s->debugMod='0';
        printf("Debug flag is now off.\n");
    }
    else{
        s->debugMod='1';
        printf("Debug flag is now on.\n");
    }
}
void ExamineElfFile(state* s)
{
    Elf32_Ehdr *head;
    int section;
    int entry;
    char buf[1024];
    printf("Please enter Elf file name: \n");
    fgets(buf,1024,stdin);
    buf[strlen(buf)-1]='\0';

    if(fd!=-1&& fd!=0)
        close(fd);
    if((fd =open(buf,O_RDONLY))<0){
        perror("failed to open file\n");
        fd=-1;
        free(s);
        exit(-1);
    }
    if(fstat(fd,&fileDesc_stat)!=0){
        perror("stat failed \n");
        close(fd);
        fd=-1;
        exit(1);
    }
    if((map_star=mmap(0,fileDesc_stat.st_size,PROT_READ,MAP_PRIVATE,fd,0))==MAP_FAILED){
        perror("mmap failed \n");
        munmap(map_star,fileDesc_stat.st_size);
        close(fd);
        fd=-1;
        free(s);
        exit(1);
    }

    head=(Elf32_Ehdr*) map_star;
    //prinbting the magic numbers(the firts three chars in the ident).
    printf("The magic numbers are: %c %c %c\n",head->e_ident[1],head->e_ident[2],head->e_ident[3]);
    if((head->e_ident[1]!='E' )&&(head->e_ident[2]!='L')&&(head->e_ident[3]!='F' )){
        fprintf(stderr,"The current file is not an elf.\n");
        munmap(map_star,fileDesc_stat.st_size);
        close(fd);
        fd=-1;
        return;
    }
    if(head->e_ident[4]==0)
    printf("The data encoding is invalid\n");
    else if(head->e_ident[4]==1){
        printf("The data encoding is 2's complement with little endian.\n");
    }
    else if(head->e_ident[4]==2){
        printf("The data encoding is 2's complement with big endian.\n");
    }
    printf("File entry point: %X\n",head->e_entry);
    printf("The file offset in which the section header table resides: %d\n",section= head->e_shoff);
    printf("The number of section header entries: %d\n",head->e_shnum);
    printf("The size of each section header entry: %d\n",head->e_shentsize);
    printf("The file offset in which the program header table resides: %d\n",head->e_phoff);
    printf("The number of program header entries: %d\n", entry=head->e_phnum);
    printf("The size of each program header entry: %d\n",head->e_phentsize);

}
void PrintSectionNames(state* s)
{
    Elf32_Ehdr * head;
    if(fstat(fd,&fileDesc_stat)!=0){
        perror("Failed to stat.\n");
        close(fd);
        fd=-1;
        exit(1);
    }
    //pointer to the elf header.
    head=(Elf32_Ehdr*)map_star;
    //pointer to the table of sections.
    Elf32_Shdr * sectionHeader = (Elf32_Shdr*)(map_star + head->e_shoff);
    //number of sections in the table.
    int sectionHeaderNum= head->e_shnum;
    //entry of the string table in the sections table.
    Elf32_Shdr * sectionsEntry=&sectionHeader[head->e_shstrndx];
    //pointer to the string table.
    char* tablePointer= map_star + sectionsEntry->sh_offset;

    if(s->debugMod-'1'==0)
    {
        fprintf(stderr,"DEBUG: shstrndx = %d\n", head->e_shstrndx);
    }
    printf("\tName\t\t\tAddress\t\tOffset\t\tSize\t\tType\n");
    int j;
    for(j=0;j<sectionHeaderNum;j++){
        printf("[%2d]",j);
        if(strlen(tablePointer+sectionHeader[j].sh_name)==0){
            printf("%s\t\t\t\t",tablePointer+sectionHeader[j].sh_name);
        }
        else if(strlen(tablePointer+sectionHeader[j].sh_name)>11){
            printf("%s\t\t",tablePointer+sectionHeader[j].sh_name);
        }
        else{
            printf("%s\t\t\t",tablePointer+sectionHeader[j].sh_name);
        }
        printf("%#09X\t",sectionHeader[j].sh_addr);
        printf("%#X\t",sectionHeader[j].sh_offset);
        printf("%#X\t",sectionHeader[j].sh_size);
        printf("%#X\t\n",sectionHeader[j].sh_type);
        if(s->debugMod-'1'==0)
            fprintf(stderr,"DEBUG: section name offset is: %#X\n\n",sectionHeader[j].sh_name);
    }
}
void PrintSymbols(state* s)
{
    Elf32_Ehdr * head;
    if(fstat(fd,&fileDesc_stat)!=0){
        perror("Failed to stat.\n");
        close(fd);
        fd=-1;
        exit(1);
    }
    //pointer to the elf header.
    head=(Elf32_Ehdr*)map_star;
    //pointer to the table of sections.
    Elf32_Shdr * sectionHeader = (Elf32_Shdr*)(map_star + head->e_shoff);
    //entry of the string table in the sections table.
    Elf32_Shdr * sectionsEntry=sectionHeader+head->e_shstrndx;
    Elf32_Sym* symbolTable;
       //pointer to the string table.
    char* tablePointer= map_star + sectionsEntry->sh_offset;
    char* string_symbolTable;
    int number=head->e_shnum;
    int size;
    int j;
    for(j=0;j<number;j++){
        if(sectionHeader[j].sh_type==SHT_DYNSYM||sectionHeader[j].sh_type==SHT_SYMTAB){
            size=sectionHeader[j].sh_size/sectionHeader[j].sh_entsize; 
            symbolTable=(Elf32_Sym *)(map_star+sectionHeader[j].sh_offset);
            string_symbolTable=map_star+sectionHeader[sectionHeader[j].sh_link].sh_offset;

            if(symbolTable==NULL)
            {
                    fprintf(stderr,"There are no symbol table.\n");
                    return;
            }
            if(sectionHeader[j].sh_type==SHT_DYNSYM)
                printf("Symbol table 'dynsym' contains %d symbols.\n",size);
            else{
                printf("Symbol table 'symtab' contains %d symbols.\n",size);
            }

                printf("[index] value\t\tsection_index\t\tsection_name\t\tsymbol_name\n");
            if(s->debugMod=='1')
                fprintf(stderr,"DEBUG: the size of the symbol table is: %x\nThe number of entries is: %d.\n",sectionHeader[j].sh_size,size);

            int x;
            for(x=0;x<size;x++){
               printf("[%2d]",x);
               printf("%#09X\t\t",symbolTable[x].st_value); 
               printf("%d\t\t",symbolTable[x].st_shndx);
               if(symbolTable[x].st_shndx==0) {
                   printf("UNDEFINED\t\t");
               }
               else if(symbolTable[x].st_shndx<number){
                   printf("%s\t\t",(char*)(tablePointer+sectionHeader[symbolTable[x].st_shndx].sh_name));
               }
               else if (symbolTable[x].st_shndx==65521)
                    printf("ABS\t\t");
                else
                {
                    printf("COM\t\t");
                }
                 printf("%s\n",(char *)(string_symbolTable+symbolTable[x].st_name));  
            } 
            printf("\n");   
        }
    }
}
void RelocationTables(state* s)
{
        Elf32_Ehdr * head;
     //pointer to the elf header.
    head=(Elf32_Ehdr*)map_star;
    //pointer to the table of sections.
    Elf32_Shdr * sectionHeader = (Elf32_Shdr*)(map_star + head->e_shoff);
    //entry of the string table in the sections table.
    Elf32_Shdr * sectionsEntry=sectionHeader+head->e_shstrndx;

    Elf32_Shdr* reloc;
    Elf32_Shdr* dynamicSymbolTable;
    char* stringDynamicSymbolTable;
    Elf32_Rel * dynamicRelocationTable;
    Elf32_Sym * SymbolTablePointer;
    char* tableString = map_star+sectionsEntry->sh_offset;
    int number= head->e_shnum;
    int i,j;
    for(i=0;i<number;i++){
        if(strcmp(tableString+sectionHeader[i].sh_name,".dynstr")==0)
        {
            stringDynamicSymbolTable=map_star+sectionHeader[i].sh_offset;
        }
         if(strcmp(tableString+sectionHeader[i].sh_name,".dynsym")==0)
        {
            dynamicSymbolTable=(Elf32_Shdr *)&sectionHeader[i];
            SymbolTablePointer=(Elf32_Sym*)(map_star+dynamicSymbolTable->sh_offset);
        }
    }
    int size;
    int index;
    j=0;
    for(i=0;i<number;i++){

        if(sectionHeader[i].sh_type==SHT_REL){
            reloc=(Elf32_Shdr*)&sectionHeader[i];
            dynamicRelocationTable=(Elf32_Rel*)(map_star+reloc->sh_offset);
            size=sectionHeader[i].sh_size/sectionHeader[i].sh_entsize;
            printf("Offset\t\tInfo\t\tType\tValue\t\tName\n");
            while(j<size){
            index=ELF32_R_SYM(dynamicRelocationTable[j].r_info); // symbol table index of the called function
            //prints offset
            printf("%08X\t",dynamicRelocationTable[j].r_offset); // location of begining of relocation
            //prints info
            printf("%08X\t",dynamicRelocationTable[j].r_info); 
            //prints type
            printf("%d\t",ELF32_R_TYPE(dynamicRelocationTable[j].r_info)); // the type of the table
            //prints value
            printf("%08X\t",SymbolTablePointer[index].st_value);
            //prints name
            if(strlen(stringDynamicSymbolTable+SymbolTablePointer[index].st_name)>14)
                printf("%s\t\n",stringDynamicSymbolTable+SymbolTablePointer[index].st_name);
            else if(strlen(stringDynamicSymbolTable+SymbolTablePointer[index].st_name)==0)
                printf("%s\t\t\t\t\n",stringDynamicSymbolTable+SymbolTablePointer[index].st_name);
            else
                printf("%s\t\t\t\n",stringDynamicSymbolTable+SymbolTablePointer[index].st_name);
            j++;
            }
            printf("\n");
            j=0;
        }
    }
}
void Quit(state* s)
{
    if(s->debugMod=='1')
        printf("Quitting nurmally...\n");
    munmap(map_star,fileDesc_stat.st_size);
    close(fd);
    free(s);
    exit(0);
}

int main(){
    state* s=malloc(sizeof(state));
    struct fun_desc menu[]={{"Toggle Debug Mode",ToggleDebugMode},{"Examine ELF File",ExamineElfFile},
    {"Print Section Names",PrintSectionNames},{"Print Symbols",PrintSymbols},{"Relocation Tables",RelocationTables},
    {"Quit",Quit},{NULL,NULL}};
    while (1)
	    {
            int i=0;
            while (menu[i].name!=NULL)
            {
                printf("%d- %s\n",i,menu[i].name);
                i++;
            }
            char in[1024];
            int option;
            option=atoi(fgets(in,1024,stdin));
            if ((option>i)||(option<0))
            {
                printf("option not valid\n");
            }
            else
            {
                menu[option].fun(s);
            }

	    }
        free(s);
       
}